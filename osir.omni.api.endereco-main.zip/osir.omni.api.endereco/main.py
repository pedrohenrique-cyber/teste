import os
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Query, Security, Depends, BackgroundTasks
from typing import List
from fastapi.security.api_key import APIKeyHeader
from starlette.status import HTTP_403_FORBIDDEN

# Importações locais
import database
import models

# 1. Carregar variáveis de ambiente antes de qualquer coisa
load_dotenv()

app = FastAPI(title="OmniAPI Endereco - Voalle")

# 2. Configuração de Segurança (Token)
API_KEY_NAME = "access_token"
api_key_header = APIKeyHeader(name=API_KEY_NAME, auto_error=False)

# Pegando o token do .env
API_TOKEN = os.getenv("API_TOKEN")

import secrets

# ... (outros imports)

async def verify_token(api_key: str = Security(api_key_header)):
    """
    Verifica se o token enviado no cabeçalho 'access_token' é igual ao do .env
    usando comparação segura para evitar ataques de tempo.
    """
    if api_key and secrets.compare_digest(api_key, API_TOKEN or ""):
        return api_key
    
    raise HTTPException(
        status_code=HTTP_403_FORBIDDEN,
        detail="Token de API inválido ou ausente."
    )

@app.get("/cidade-contrato", response_model=models.CidadeResponse, dependencies=[Depends(verify_token)])
def get_cidade_por_contrato(
    background_tasks: BackgroundTasks, 
    contract_id: int = Query(..., description="ID do contrato")
):
    # ... (query SQL mantida)
    sql_query = """
        SELECT 
            CASE 
                WHEN cidade_tratada = 'CIDADE DESCONHECIDA' THEN (
                    SELECT 
                        UPPER(
                            REPLACE(
                                TRANSLATE(
                                    COALESCE(NULLIF(TRIM(p.city), ''), 'CIDADE DESCONHECIDA'),
                                    'áàãâäéèêëíìîïóòõôöúùûüçÁÀÃÂÄÉÈÊËÍÌÎÏÓÒÕÔÖÚÙÛÜÇ',
                                    'aaaaaeeeeiiiiooooouuuucAAAAAEEEEIIIIOOOOOUUUUC'
                                ),
                                '''',
                                ''
                            )
                        )
                    FROM people p
                    JOIN contracts cts ON cts.client_id = p.id
                    WHERE cts.id = %s
                    LIMIT 1
                )
                ELSE cidade_tratada
            END AS city
        FROM (
            SELECT 
                UPPER(
                    REPLACE(
                        TRANSLATE(
                            COALESCE(NULLIF(TRIM(ac.city), ''), 'CIDADE DESCONHECIDA'),
                            'áàãâäéèêëíìîïóòõôöúùûüçÁÀÃÂÄÉÈÊËÍÌÎÏÓÒÕÔÖÚÙÛÜÇ',
                            'aaaaaeeeeiiiiooooouuuucAAAAAEEEEIIIIOOOOOUUUUC'
                        ),
                        '''',
                        ''
                    )
                ) AS cidade_tratada
            FROM authentication_contracts ac
            WHERE ac.contract_id = %s
        ) t;
    """

    try:
        results = database.execute_query(sql_query, (contract_id, contract_id))
        
        if not results:
            background_tasks.add_task(database.save_api_log, "Não Encontrado", contract_id, "JSON", "Aviso")
            raise HTTPException(status_code=404, detail=f'Contrato {contract_id} não encontrado.')
        
        cidade = results[0]['city']
        background_tasks.add_task(database.save_api_log, cidade, contract_id, "JSON", "Sucesso")
        
        return results[0]

    except HTTPException as e:
        raise e
    except Exception as e:
        # Logamos o erro detalhado no seu banco de logs (seguro)
        background_tasks.add_task(database.save_api_log, f"ERRO CRÍTICO: {str(e)[:200]}", contract_id, "JSON", "Erro")
        
        # Mas para o usuário externo, damos uma resposta genérica
        raise HTTPException(
            status_code=500, 
            detail="Ocorreu um erro interno ao processar a consulta. Por favor, tente novamente mais tarde."
        )

if __name__ == "__main__":
    import uvicorn
    # Usa a porta do .env ou 8000 por padrão
    port = int(os.getenv("API_PORT", 8000))
    print(f"Iniciando OmniAPI na porta {port}...")
    uvicorn.run("main:app", host="0.0.0.0", port=port, reload=True)
