from pydantic import BaseModel

class CidadeResponse(BaseModel):
  city: str

class ErrorResponse(BaseModel):
  detail: str