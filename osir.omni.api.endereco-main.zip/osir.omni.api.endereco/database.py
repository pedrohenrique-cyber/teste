import os
import psycopg2
from psycopg2 import pool
from psycopg2.extras import RealDictCursor
from dotenv import load_dotenv

load_dotenv()

# Configuração do Pool de Conexões para o Banco Voalle (Main)
try:
    voalle_pool = psycopg2.pool.SimpleConnectionPool(
        1, 20, # Mínimo 1, Máximo 20 conexões
        host=os.getenv("DB_HOST"),
        port=os.getenv("DB_PORT"),
        database=os.getenv("DB_NAME"),
        user=os.getenv("DB_USER"),
        password=os.getenv("DB_PASSWORD")
    )
    print("Pool de conexões Voalle criado com sucesso.")
except Exception as e:
    print(f"Erro ao criar pool Voalle: {e}")
    voalle_pool = None

# Configuração do Pool de Conexões para o Banco de Logs
try:
    log_pool = psycopg2.pool.SimpleConnectionPool(
        1, 10, # Mínimo 1, Máximo 10 conexões
        host=os.getenv("LOG_DB_HOST"),
        port=os.getenv("LOG_DB_PORT"),
        database=os.getenv("LOG_DB_NAME"),
        user=os.getenv("LOG_DB_USER"),
        password=os.getenv("LOG_DB_PASSWORD")
    )
    print("Pool de conexões de Logs criado com sucesso.")
except Exception as e:
    print(f"Erro ao criar pool de Logs: {e}")
    log_pool = None

def execute_query(query, params=None):
    """Executa uma query usando o pool de conexões"""
    connection = None
    try:
        if not voalle_pool:
            raise Exception("Pool de conexões Voalle não inicializado.")
            
        connection = voalle_pool.getconn()
        cursor = connection.cursor(cursor_factory=RealDictCursor)
        cursor.execute(query, params or ())
        results = cursor.fetchall()
        cursor.close()
        return results
    except Exception as e:
        print(f"Erro ao executar a query: {e}")
        raise e
    finally:
        if connection:
            voalle_pool.putconn(connection)

def save_api_log(cidade, contrato, returned_type, status):
    """Salva o log usando o pool de conexões de logs"""
    connection = None
    try:
        if not log_pool:
            return # Se não houver pool de logs, apenas ignora
            
        connection = log_pool.getconn()
        cursor = connection.cursor()
        query = """
            INSERT INTO automation.etl_omnichatbot_api.api_endereco_logs (cidade, contrato, returned_type, status) 
            VALUES (%s, %s, %s, %s)
        """
        cursor.execute(query, (cidade, contrato, returned_type, status))
        connection.commit()
        cursor.close()
    except Exception as e:
        print(f"Erro ao salvar log: {e}")
    finally:
        if connection:
            log_pool.putconn(connection)
